<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; Garut 2021
    </div>
    <div class="footer-right">

    </div>
</footer>
</div>
</div>

<!-- General JS Scripts -->
<script src="<?= base_url('assets_petugas/'); ?>modules/jquery.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/popper.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/tooltip.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/nicescroll/jquery.nicescroll.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/moment.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>js/stisla.js"></script>

<!-- JS Libraies -->
<script src="<?= base_url('assets_petugas/'); ?>modules/datatables/datatables.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/jquery-ui/jquery-ui.min.js"></script>

<script src="<?= base_url('assets_petugas/'); ?>modules/jquery.sparkline.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/chart.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/owlcarousel2/dist/owl.carousel.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/summernote/summernote-bs4.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/codemirror/lib/codemirror.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/codemirror/mode/javascript/javascript.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/jquery-selectric/jquery.selectric.min.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

<!-- Page Specific JS File -->
<script src="<?= base_url('assets_petugas/'); ?>js/page/index.js"></script>

<!-- Template JS File -->
<script src="<?= base_url('assets_petugas/'); ?>js/scripts.js"></script>
<script src="<?= base_url('assets_petugas/'); ?>js/custom.js"></script>
</body>

</html>