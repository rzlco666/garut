<?php

echo 'RESULT <br><pre>';
		var_dump($result);
		echo '</pre>';
